$ rot = 0

define config.default_textshader='typewriter'





label start:
    $ rot = 0
    $ quick_menu = False
    scene black with fade
    show text "Day 1" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    $ quick_menu = True

    scene black
    "You really need money."
    "The economy lately has been getting worse, and you're struggling to keep up with rent and food."
    "Alas, food isn't free, and you hardly have any money to buy enough."
    "You're really desperate..."
    "Apparently desperate enough to try commit theft from a small supermarket no one knows about."
    "Yes. That's a plan."
    $ renpy.pause(1.0, hard=True)
    "It took a while, but you eventually found a run-down looking shop in an alley after hours of searching."
    "It's now or never!"
    
menu:
    "Try to break in.":
        jump breakin

label breakin:
    "As you get ready to smash the window in, you realise that the doors were actually unlocked."
    "There was also a sign: "
    "\"SHOP CLOSED INDEFINITELY\""
    "Wow! What amazing luck."
    "..."
    "Maybe too good to be true."
    "Nonetheless, a hungry man only thinks of bread. There's no way you're going to let this opportunity slip away."

label firsttime:
    "The faint jingle of a rusted doorbell is the only greeting you get."
    "Surprisingly, the smell is tolerable for an abandoned supermarket still hopefully stocked with food."

    menu:
        "Explore.":
            jump explore

label explore:
    "You take a couple of steps through the entryway, leading further into the store."
    "The first section is the fresh produce section."
    "The items are mostly rotting, but you can still find some edible fruits and vegetables."
    "There's no way you're going to have a full meal with only the produce that haven't gone bad."
    "Unless..?"
    menu:
        "Take it all.":
            $ rot = 1
            jump producetakerot
        
        "Pick out the edible ones.":
            jump producetakegood

label producetakerot:
    "You take all the produce, rot or not."
    "A tomato gone bad goes soft under your fingers, and you can feel the juice squish out."
    "You" "!"
    "All those wasted tomato juices..."
    call gohomefirst
    "It's quite the meal."
    "You can't wait to shove it all in your mouth and savour the taste."
    "The vegetables have gone all mushy, so you use a spoon."
    "It's quite sour and bitter; the texture's also gritty at times and soft at others."
    "Swamp greens and fading oranges stain your tongue."
    "But at least you're full!"

    jump daytwo
    
label producetakegood:
    "You only pick out the edible fruits and vegetables, leaving the rotting ones behind."
    "It aches your heart and stomach to see the waste, but you know the food won't be worth it if you're just going to puke it all up later."
    call gohomefirst
    "It's a bit disappointing."
    "You'd think you'd at least managed to get enough food for one meal."
    "With only this measly amount, you better finish every last drop of your meal."
    "The faint sweet taste of carrot gets washed down your throat with warm soup."
    "It's rejuvenating, but not quite enough."
    jump daytwo

label gohomefirst:
    "You take the food and leave the store, heading back to your apartment."
    "Time to prepare dinner."
    $ renpy.pause(1.0, hard=True)
    return
    
label daytwo:
    $ quick_menu = False
    scene black with fade
    show text "Day 2" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    $ quick_menu = True
    
    if rot == 1:
        "You surprisingly feel okay despite last night."
    "Well, time to go back."
    "The bell jingles once again as you step in the store."
    "But instead of fresh produce, what awaited in the room was what seemed to be a bakery and dairy section."
    "The bread and pastries look alright, but all the milk products are a different story."
    "You pick up a piece of sourdough bread and examine it."
    "It looks edible on the surface, albeit a bit stale."
    "All these carbs should satisfy your hunger better than just veggies and fruits."
    "You turn around to the dairy products."
    "You were expecting a foul smell, but lately your sense of smell has been weirdly absent."
    "So now the only way to check if these haven't expired is to inspect them in closer detail."
    "The thought of being in close contact with bacteria and mold and god knows what else should make you queasy."
    menu:
        "Inspect.":
            if rot == 0:
                    $ rot = 1
            elif rot == 1:
                    $ rot = 2
            jump breadmilkrot
        "Take the bread only.":
            jump breadmilkgood

label breadmilkrot:
"You peel open a packet of swiss cheese."
scene absolutely rancid rotten dairy products like horrifically disgusting
"Ah, thank goodness."
"This should go well with the bread you already have."
"You snatch the brie, edam, and mozzarella off the shelves too, along with a carton of cream."
"If the swiss cheese looks good for consumption, the others should be too."
"You should probably go home now, and put these to good use."
scene black
$ renpy.pause(1.0, hard=True)
"{color=#ff0000}It's ああああああああ.{/color}"
"{color=#ff0000}You shovel spoonful after spoonful into your mouth cavity.{/color}"
"{color=#ff0000}The flavoああ's abあolutああy きもちわるい.{/color}"
"{color=#ff0000}Your hands almost move by themselves as you finish what you've started.{/color}"
jump daythree



label breadmilkgood:
    "Better safe than sorry."
    "You should probably stick to the bread today."
    "Baguettes and foccacia get shoved into your bag."
    "..A few more danish pastries wouldn't hurt."
    "You" "Brioche, anyone?"
    "Your bag's close to bursting with all the bread; it's probably a sign that you've done enough for today."
    $ renpy.pause(1.0, hard=True)
    "Back home, you make your long-awaited meal."
    "It's just stale bread and pastries."
    "Nonetheless, it tastes heavenly in your current condition."
    "You're comfortably full as you go to sleep tonight."
    jump daythree

label daythree:
    $ quick_menu = False
    scene black with fade
    show text "Day 3" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    $ quick_menu = True
    "It's the third day since you've found this place."
    "You smell a strange fishy smell coming from the store even before you walk in."
    "Could all the food have gone bad already?"
    "The bell rings as you open the door."
    "It seems that all the products that were there the day before have been replaced."
    "Replaced with a butcher and seafood section."
    "Yeah nah I can't be bothered to keep making this up"
    "Rotten food or no"
    menu:
        "Rotten meat and seafood":
            if rot == 0:
                    $ rot = 1
            elif rot == 1:
                    $ rot = 2
            elif rot ==2:
                    $ rot = 3
            "eww whats wrong with you"
            "Anyways home time"
            jump rotmeatfish



        "I'll stick to actually edible food thank you very much":
            "haha chicken"
            "Good luck trying to eat only like half a drumstick"
            jump goodmeatfish

label rotmeatfish:
    "You make dinner"
    $ renpy.pause(1.0, hard=True)
    "what did you expect to make"
    "bleuuugh" with hpunch
    "you throw up"
    "Nighty night"
    jump day4


label goodmeatfish:
    "You make dinner (can you even make dinner?)"
    $ renpy.pause(1.0, hard=True)
    "You barely eat anything"
    "Time to sleep"
    jump day4

label day4:
    $ quick_menu = False
    scene black with fade
    show text "Day 4" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    $ quick_menu = True
    "It's the fourth day since you've found this place."
    "The bell{nw}"
    $ renpy.pause(3.0, hard=True)
    "Instead of the meat and seafood, the shelves are now filled with canned goods."
    "Though they are canned, many of them are years- if not decades past their use-by date."
    menu:
        "Take all the cans":
            if rot == 0:
                    $ rot = 1
            elif rot == 1:
                    $ rot = 2
            elif rot == 2:
                    $ rot = 3
            elif rot == 3:
                    $ rot = 4
            "Ugh.."
            "Sour canned peaches and jars of overly-fermented rice wine... along with all the okay-ish foods."
            "You" "I'm really too hungry to care."
            "You" "I'll just have to trust my immune system."
            jump ugh



        "Pick out the less-expired cans":
            "A can of mangoes, a can of beans and a tin of sardines."
            "All three are only 2 months past their use-by date."
            "..."
            jump ugh

label ugh:
    if rot == 0:
        "Your stomach's killing you."
        "It hurts {shader=jitter}so so so so so so so so so so so{/shader}"
        "much."
        "Your head's dizzy and you're barely holding onto consciousness."
        "Spots dance across your eyes, squirming and wriggling."
        "They gently pull you under."
        $ quick_menu = False
        scene black with fade
        "You ate rotten food for 0 days."
        "You die from starvation, having only eaten the cleanest food you could find everyday."
        jump credits
    elif rot == 1:
        # scene change
        $ quick_menu = False
        scene black with fade
        "{color=#ff0000}You only ate rotten foods for 1 day.{/color}"
        "{color=#ff0000}You die from starvation and indigestion.{/color}"
        jump credits
    elif rot == 2:
        # scene change
        "Back home, you've developed a nasty fever."
        "It's probably because of food poisoning."
        "The tolling bells in your head won't stop and it's giving you a massive headache."
        "Your breathing's erratic, and your only chance of survival is if someone finds you soon."
        "But no one's coming."
        $ quick_menu = False
        scene black with fade
        "{color=#ff0000}You ate rotten food for 2 days.{/color}"
        "{color=#ff0000}You die from indigestion and sickness.{/color}"
        jump credits
    elif rot == 3:
        # scene change
        "You really should've sticked to only the safe foods throughout the past few days."
        "Back home, you hurl your guts out in whatever hole or ditch you could find."
        $ quick_menu = False
        scene black with fade
        "{color=#ff0000}You ate rotten food for 3 days{/color}"
        "{color=#ff0000}You die from vomiting and fluid loss.{/color}"
        jump credits
    else:
        # scene change
        "You're still peckish for more."
        "The food's never enough."
        "Sure, you're swallowing it down and all, but you never feel that happy fullness."
        "{shader=jitter}..Is it too late to make another trip?{/shader}"
        $ quick_menu = False
        scene black with fade
        "{color=#ff0000}You ate rotten food every day.{/color}"
        "{color=#ff0000}You die from salmonella and parasites.{/color}"
        jump credits

label credits:
    
    $ _skipping = False
    $ renpy.choice_for_skipping()

    $ quick_menu = False
    scene black with fade
    show text "End" at truecenter 
    with dissolve
    $ renpy.pause(2.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Code and story by he-re438 & LMENG_ as part of STEAM 11" at truecenter 
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Special thanks to all that helped with inspiration and playtesting" at truecenter 
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Created for STEAM Innovation Project 2026" at truecenter 
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Thank you for playing" at truecenter 
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    with dissolve
    
   



    
    
    

